export const mockEmployees = [
    { id: 1, name: 'Juanjo', role: 'Empleado' },
    { id: 2, name: 'Alicia', role: 'Gestor de RRHH' },
    { id: 3, name: 'Carlos', role: 'Empleado' },
    { id: 4, name: 'Lucía', role: 'Empleado' },
    { id: 5, name: 'Marta', role: 'Empleado' },
    { id: 6, name: 'David', role: 'Empleado' },
];
