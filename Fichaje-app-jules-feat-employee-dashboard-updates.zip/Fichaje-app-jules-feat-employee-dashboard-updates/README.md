# mi-app-fichaje
Frontend para el plugin de fichajes con SvelteKit y Tailwind
